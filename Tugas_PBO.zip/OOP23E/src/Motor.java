public class Motor extends Kendaraan{
    boolean memilikiBox;

    public Motor(boolean memilikiBox, String namaPemilik, String nomorPlat, String jenisKendaraan) {
        super(namaPemilik, nomorPlat, jenisKendaraan);
        this.memilikiBox = memilikiBox;
    }

    public boolean isMemilikiBox() {
        return memilikiBox;
    }

    public void setMemilikiBox(boolean memilikiBox) {
        this.memilikiBox = memilikiBox;
    }
    
    public void infoMemilikiBox(){
        System.out.println("Apakah Motor :" + getMemilikiBox());
    }
}
