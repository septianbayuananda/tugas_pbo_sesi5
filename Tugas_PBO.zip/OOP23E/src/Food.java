public class Food extends Product {
    String expered;

    public Food(String expered, String name, double price) {
        super(name, price);
        this.expered = expered;
    }

    public String getExpered() {
        return expered;
    }

    public void setExpered(String expered) {
        this.expered = expered;
    }
    public void infoProduct(){
        super.infoProduct();
        System.out.println("expered in:" + getExpered());
    }

}
