public class Product {
    String name;
    double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }
    
   

    public String getName() {
        return name;
    }

    public double getPrice(double discount) {
        return price - (price * (discount/100));
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    public void infoProduct(){
        System.out.println("Nama Barang :" + getName());
        System.out.println("Harga Barang :" + price);
    }
}
