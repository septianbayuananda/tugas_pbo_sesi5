public class ECommerce {
    
     public static void main (String [] args){
        Electronic laptop = new electronic(400000,"asus",2);
        Clothes kaos = new Clothes(name:"RUCAS",price:300000,size:44,material:cotton);
        Food mie =  new Food(name:"Indomie Goreng", price: 3000, expired:"02/04/2028");
        laptop.infoProduct();
        kaos.infoProduct();
        mie.infoProduct();
        
    }
    
}
