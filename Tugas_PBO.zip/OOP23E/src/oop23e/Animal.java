/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop23e;

/**
 *
 * @author KOMPUTER JARKOM 22
 */
public class Animal {
    String gender; //Male or Female
    String classfied; //Reptile, Mamalia
    String name;
    
    public Animal() {
        gender = "Male";
        classfied = "Reptile";
        name ="";
    }
    
    public void setAnimal(String gender,String classfied, String name) {
        this.gender = gender;
        this.classfied = classfied;
        this.name = name;
    }
    
    public String gerGender() {
        return gender;
    }
    
    
    public String getClassFied() {
        return classfied;
    }
    
    public String getName() {
        return name;
    }
}
