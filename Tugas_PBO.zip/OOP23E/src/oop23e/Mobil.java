/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop23e;

/**
 *
 * @author KOMPUTER JARKOM 22
 */
public class Mobil {
    String warna;
    int tahun;
    int kecepatan;
    boolean status = false;

    //Mutator/setter method
    public void setDataMobil(String c, int y, int kecepatan){
        warna = c;
        tahun = y;
        this.kecepatan = kecepatan;
    }

    //Accessor/getter method
    public String getWarna() {
        return warna;
    }

    public int getTahun() {
        return tahun;
    }

    public int getKecepatan() {
        return kecepatan;
    }
    
    public void tambahKecepatan(int kecepatanTambahan) {
        if (status == true) {
            kecepatan += kecepatanTambahan;
        }
    }
    
    public void hidupkanMobil() {
        status = true;
    }
    
    public void matikanMobil () {
        status = false;
    }
    
    public void infoMobil() {
        System.out.println("Warna Mobil" + getWarna());
        System.out.println("Tahun Pembuatan" + getTahun());
        System.out.println(" Kecepatan" + getKecepatan());
        System.out.println("=======================");
    }
}
