/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop23e;

import java.util.Scanner;

/**
 *
 * @author KOMPUTER JARKOM 22
 */
public class ObjectSegitiga {
       public static void main(String[] args) {
        System.out.println("================");
        System.out.println("1. Bujur Sangkar");
        System.out.println("2. Segitiga");
        System.out.println("3. Persegi Panjang");
        System.out.println("================");
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Masukan Pilihan:");
        int pilihan = sc.nextInt();
        
        if (pilihan == 2) { // If user selects Segitiga (Triangle)
            System.out.print("Isikan Alas (Base): ");
            int alas = sc.nextInt();
            System.out.print("Isikan Tinggi (Height): ");
            int tinggi = sc.nextInt();
            
            // Create an object of the Triangle (Segitiga) class
            Segitiga segitiga = new Segitiga(alas, tinggi);
            segitiga.info();
        }
    }
}
