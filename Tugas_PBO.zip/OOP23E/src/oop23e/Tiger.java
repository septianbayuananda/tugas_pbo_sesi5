/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop23e;

/**
 *
 * @author KOMPUTER JARKOM 22
 */
public class Tiger extends Animal {
    int age;
    public Tiger(int age) {
        super.name = "Tiger";
        this.age = age;
        super.classfied = "mamalia";
    }
    
    public void info() {
        System.out.println("My name is:" + super.name);
        System.out.println("My name is:" + super.classfied);
    }
    
    public void SetAge (int age) {
        this.age = age;
    }
    
    public int getAge() {
        return age;
    }
}
