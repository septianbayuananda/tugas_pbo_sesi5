/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop23e;

/**
 *
 * @author KOMPUTER JARKOM 22
 */
public class PersegiPanjang {
    int panjang;  // Length of the rectangle
    int lebar;    // Width of the rectangle
    
    public PersegiPanjang(int panjang, int lebar) {
        this.panjang = panjang;
        this.lebar = lebar;
    }
    
    public void setBangunDatar(int panjang, int lebar) {
        this.panjang = panjang;
        this.lebar = lebar;
    }
    
    public int getPanjang() {
        return panjang;
    }
    
    public int getLebar() {
        return lebar;
    }
    
    public int hitungLuas() {
        return panjang * lebar;
    }
    
    public int hitungKeliling() {
        return 2 * (panjang + lebar);
    }
    
     public void info() {
        System.out.println("Persegi Panjang dengan Panjang: " + panjang + " dan Lebar: " + lebar);
        System.out.println("Luas Persegi Panjang: " + hitungLuas());
        System.out.println("Keliling Persegi Panjang: " + hitungKeliling());
    }
}
