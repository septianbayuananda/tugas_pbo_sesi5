/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop23e;

/**
 *
 * @author KOMPUTER JARKOM 22
 */
public class Segitiga {
    int alas;  // base of the triangle
    int tinggi; // height of the triangle
    
    
    public Segitiga(int alas, int tinggi) {
        this.alas = alas;
        this.tinggi = tinggi;
    }
    
    public void setBangunDatar(int alas, int tinggi) {
        this.alas = alas;
        this.tinggi = tinggi;
    }
    
    public int getAlas() {
        return alas;
    }
    
    public int getTinggi() {
        return tinggi;
    }
    
    public double hitungLuas() {
        return 0.5 * alas * tinggi;
    }
    
     public void info() {
        System.out.println("Segitiga dengan Alas: " + alas + " dan Tinggi: " + tinggi);
        System.out.println("Luas Segitiga: " + hitungLuas());
    }
}