/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop23e;

/**
 *
 * @author KOMPUTER JARKOM 22
 */
public class BangunDatar {
    int panjang;
    int lebar;
    
    public BangunDatar(int panjang, int lebar) {
        this.panjang = panjang;
        this.lebar = lebar;
    }
    
    public void setBangunDatar(int panjang, int lebar) {
        this.panjang = panjang;
        this.lebar = lebar;
    }
    
    public int getPanjang() {
        return panjang;
    }
    
    public int getLebar() {
        return lebar;
    }
}
