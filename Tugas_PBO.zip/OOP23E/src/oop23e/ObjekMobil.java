/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop23e;

/**
 *
 * @author KOMPUTER JARKOM 22
 */
public class ObjekMobil {
    public static void main(String[] args) {
        Mobil mobilku = new Mobil();
        Mobil mobilmu = new Mobil();
        
        mobilku.setDataMobil("Biru", 2000, 0);
        mobilmu.setDataMobil("Hitam", 2024, 0);
        
        mobilku.hidupkanMobil();
        mobilmu.hidupkanMobil();
        
        mobilku.tambahKecepatan(10);
        mobilku.tambahKecepatan(20);
        
        mobilku.infoMobil();
        mobilmu.infoMobil();
    }
}
