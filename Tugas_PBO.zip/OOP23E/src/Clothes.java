public class Clothes extends Product {
    int Size;
    String material;

    public Clothes(int Size, String material, double price) {
        this.Size = Size;
        this.material = material;
    }
    
    

    public int getSize() {
        return Size;
    }

    public void setSize(int Size) {
        this.Size = Size;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
    public void infoProduct(){
        super.infoProduct();
        System.out.println("Size  :" + getSize());
        System.out.println("Material :" + getMaterial());
        
    }
    
}
